import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Logins } from './logins';
import { Users } from './user/users';

@Injectable({
  providedIn: 'root'
})

export class LoginserviceService {

  // private baseURL ="http://localhost:8091/login/signin";
  url = "http://localhost:8091"
  

  constructor(private http : HttpClient) { }

  // loginUser(userdetails: Logins):Observable<object>{
  //   console.log(userdetails);
  //   return this.httpClient.post(`${this.baseURL}`,userdetails);
  //}
  // Login Service
  loginUser(userdetails: Logins):Observable<object>{
    return this.http.post(`${this.url+"/login/signin"}`,userdetails);
  }

  getAllUserDetails(): any {
    return this.http.get(this.url+'/users');
  }

  getSingleUserDetails(id: String){
    return this.http.get(this.url+'/users'+id);
  }
  orderDetails(): any {
    // return this.http.post(`${this.url+"/login/signin"}`);
  }

}

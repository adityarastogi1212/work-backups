export class Users {
    id!: String;
    name!: String;
    password!: String;
    about!: String;
    email!: String;
    itemname!: String;
    quantity!: String;
    totalprice!: String;
}
import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { LoginserviceService } from '../loginservice.service';
import { Users } from './users';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent {
  users: Users = new Users();
  route: Router = new Router; 



  constructor(private LoginService: LoginserviceService) { 
}

  ngOnInit(): void {
  }


  //constructor(@Inject(DOCUMENT) private document: Document) {}


// gotoUrl(): void{
//   //window.location.href= "http://localhost:3000";
//   window.open("http://localhost:8090/users");
// }




 Order (){
      
      console.log(this.users);
      // this.LoginService.orderDetails(this.users).subscribe(data=>
      //   {
      //     alert("Order Succesfull")
          // this.gotoUrl();
          // this.route.navigate(['user-dashboard']);
        // },
        // error=>alert("Please Try Again ")
        // );
 }
}

import { DOCUMENT } from '@angular/common';
import { Component, Inject, OnInit } from '@angular/core';
import { Logins } from '../logins';
import { LoginserviceService } from '../loginservice.service';
// import Bootstrap from 'bootstrap/dist/js/bootstrap.js';
import { Router } from '@angular/router';

@Component({
  selector: 'app-signin',
  templateUrl: './signin.component.html',
  styleUrls: ['./signin.component.css']
})
export class SigninComponent implements OnInit {

 
  logins: Logins=new Logins();
  route: Router = new Router;



  constructor(private LoginService: LoginserviceService) { 
}

  ngOnInit(): void {
  }


  //constructor(@Inject(DOCUMENT) private document: Document) {}


// gotoUrl(): void{
//   //window.location.href= "http://localhost:3000";
//   window.open("http://localhost:8090/users");
// }




 User (){
      
      console.log(this.logins);
      this.LoginService.loginUser(this.logins).subscribe(data=>
        {
          alert("Login Succesfull")
          // this.gotoUrl();
          this.route.navigate(['user-dashboard']);
        },
        error=>alert("Please Enter correct Credentials ")
        );
 }
 

}

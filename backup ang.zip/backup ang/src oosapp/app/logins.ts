export class Logins {
    
    username: String="";
    password: String="";

}

import { DOCUMENT } from '@angular/common';
import { Component, Inject, OnInit } from '@angular/core';
import { Logins } from '../logins';
import { LoginserviceService } from '../loginservice.service';
// import Bootstrap from 'bootstrap/dist/js/bootstrap.js';

@Component({
  selector: 'app-signin',
  templateUrl: './signin.component.html',
  styleUrls: ['./signin.component.css']
})
export class SigninComponent implements OnInit {

 
  logins: Logins=new Logins();



  constructor(private LoginService: LoginserviceService) { 
}

  ngOnInit(): void {
  }


  //constructor(@Inject(DOCUMENT) private document: Document) {}


gotoUrl(): void{
  //window.location.href= "http://localhost:3000";
  window.open("http://localhost:3000");
}




 User (){
      
      console.log(this.logins);
      this.LoginService.loginUser(this.logins).subscribe(data=>
        {
          alert("Login Succesfull")
          this.gotoUrl();
        },
        error=>alert("Please Enter correct Credentials ")
        );
 }
 

}

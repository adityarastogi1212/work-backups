import { Logins } from './logins';

describe('Logins', () => {
  it('should create an instance', () => {
    expect(new Logins()).toBeTruthy();
  });
});

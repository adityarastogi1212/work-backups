import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Logins } from './logins';

@Injectable({
  providedIn: 'root'
})

export class LoginserviceService {

  private baseURL ="http://localhost:8081/login/signin";

  constructor(private httpClient: HttpClient) { }

  loginUser(userdetails: Logins):Observable<object>{
    console.log(userdetails);
    return this.httpClient.post(`${this.baseURL}`,userdetails);
  }


}

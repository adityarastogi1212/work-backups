package com.lti.candidate;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CandidateDashboardServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}

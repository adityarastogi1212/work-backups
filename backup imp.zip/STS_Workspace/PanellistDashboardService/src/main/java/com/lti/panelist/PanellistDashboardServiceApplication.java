package com.lti.panelist;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PanellistDashboardServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(PanellistDashboardServiceApplication.class, args);
	}

}

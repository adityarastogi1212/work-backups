package com.interview;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ScheduleInterviewServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}

package com.kafka.orderservice.entity;

//import lombok.Getter;
//import lombok.Setter;
//import org.springframework.boot.autoconfigure.domain.EntityScan;

//import java.persistence.Entity;
//@Entity
//@EntityScan
//@Table(name = "ordering_recentchange")
//@Getter
//@Setter
//
//public class OrderingData {
//    @Id
//    @GeneratedValue(strategy = GenerationType.IDENTITY)
//    private Long id;
//    //@Lob
//    private String name;
//    private int num;
//    private long price;
//}

package com.kafka.orderservice.repository;

//import com.kafka.orderservice.entity.OrderingData;
//import org.springframework.boot.autoconfigure.data.jpa.JpaRepositoriesAutoConfiguration;

//public interface OrderingDataRepository extends JpaRepositoriesAutoConfiguration<OrderingData, Long> {
//}

package com.kafka.orderservice.controller;

import com.kafka.basedomains.dto.Order;
import com.kafka.basedomains.dto.OrderEvent;
import com.kafka.orderservice.entity.OrderDetails;
import com.kafka.orderservice.kafka.OrderProducer;
import com.kafka.orderservice.repository.OrderDetailsRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Random;

@RestController
@RequestMapping("/api/v1")
public class OrderController {

    private OrderProducer orderProducer;

    @Autowired
    private OrderDetailsRepository repo;

    public OrderController(OrderProducer orderProducer) {
        this.orderProducer = orderProducer;
    }

    @PostMapping("/orders")
    public String placeOrder(@RequestBody Order order){
        order.setOrderId(new Random().nextInt(900000) + 100000);
        OrderEvent orderEvent = new OrderEvent();
        orderEvent.setMessage("order status is in pending state");
        orderEvent.setStatus("Pending");
        orderEvent.setOrder(order);
        orderProducer.sendMessage(orderEvent);

        OrderDetails o1 = new OrderDetails();
        o1.setOrderId(order.getOrderId());
        o1.setName(order.getName());
        o1.setQty(order.getQty());
        o1.setPrice(order.getPrice());

        System.out.println(order + "\n" + o1);
        repo.save(o1);

        return "Order placed Successfully";
    }

    @GetMapping("/getOrder")
    public String getOrder(){
        return "Hi!";
    }
}



package com.kafka.orderservice.entity;


import lombok.Getter;
import lombok.Setter;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="orderDetails")
@Getter
@Setter
public class OrderDetails {

    @Id
    private int orderId;
    private String name;
    private int qty;
    private double price;

}
